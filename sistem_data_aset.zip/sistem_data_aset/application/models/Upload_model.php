<?php

/** 
 *
 * @author 		author
 * @package 	Codeigniter
 *
 */

// Model untuk upload

class Upload_model extends CI_Model {


	function __construct()
	{
		parent::__construct();

		// helper

		// library
		$this->load->library(array('PHPExcel','PHPExcel/IOFactory'));
		$this->load->library('upload');
	}

	public function process()
	{	
		// mengambil data form
		$type 	  = $this->input->post('tipe');
		$date_up  = $this->input->post('tgl');
		$month	  = $this->input->post('bulan');
		$year	  = $this->input->post('tahun');
		$perm 	  = $this->input->post('perm');

		// menetapkan row
		$row      = 0;

		// 
		// kondisi utnuk permission
		//
		// ini akan menentukan jenis upload dan insert data nya
		//

		if($perm == 'admin')
		{
			$from = 6;
		}
		elseif($perm == 'mja')
		{
			$from = 6;
		}
		elseif($perm == 'mjk')
		{
			$from = 7;
		}
		elseif($perm == 'jbg')
		{
			$from = 8;
		}
		elseif ($perm == 'ngr') 
		{
			$from = 9;
		}
		elseif($perm == 'pls')
		{
			$from = 10;
		}
		elseif($perm == 'mjs')
		{
			$from = 11;
		}
		elseif($perm == 'pct')
		{
			$from = 12;
		}
		elseif($perm == 'kts')
		{
			$from = 13;
		}
		elseif($perm == 'wrj')
		{
			$from = 14;
		}
		elseif($perm == 'ngk')
		{
			$from = 15;
		}

		// kondisi permission selesai

		// file 
		// random angka untuk membedakan file
		$rn   = 'item'.mt_rand(0, 99);

		$rep_array = array('!', '@', '#', '$', '%', '^', '&', '*', '(', ')', '-','_', '+', ' ','=', '|', '/', '"', "'", '{', '}', '[', ']', ':', ';', '?', '>', '<', ',', '.');

		// proses upload
		$extension = substr($_FILES['excel']['name'], strrpos($_FILES['excel']['name'], '.') + 1);
		$fileInit = $rn.'_' .str_replace($rep_array, '_', $this->input->post('nama'));
		$filename = $this->input->post('nama');
        
        $ar_rep	  = array(
        			'.xls', '.xlsx', '.csv'
        	);
		// data tanggal
		$date 	  = date('Y-m-d H:i:s');

        // konfigurasi upload
        $config['upload_path'] = './assets/excel'; //buat folder dengan nama assets di root folder
        $config['file_name'] = $fileInit;
        $config['allowed_types'] = 'xls|xlsx|csv'; // format yang di perbolehkan
        $config['max_size'] = 10000; // maksimal ukuran file
        
        // load library dan inisialisasi konfigurasi
        
        $this->upload->initialize($config);
         
        if(! $this->upload->do_upload('excel') ) // jika tidak melakukan upload
        {
        	$this->upload->display_errors();// jika upload gagal muncul error
        }
        else
        {

        	// memasukan file ke database
        	if($type == 'new')
        	{
				$data = [
					'tanggal_upload' 	=> $this->input->post('tgl'),
					'judul' 			=> $this->input->post('nama'),
					'nama' 				=> $fileInit,
					'ekstensi' 			=> substr($_FILES['excel']['name'], strrpos($_FILES['excel']['name'], '.') + 1),
					'keterangan'		=> 'Data Baru',
					'bulan' 			=> $month,
					'tahun' 			=> $year,
				]; 
			}
			elseif($type == 'update')
			{
				$data = [
					'tanggal_upload' 	=> $this->input->post('tgl'),
					'judul' 			=> $this->input->post('nama'),
					'nama' 				=> $fileInit,
					'ekstensi' 			=> substr($_FILES['excel']['name'], strrpos($_FILES['excel']['name'], '.') + 1),
					'keterangan'		=> 'Data Perbaikan',
					'bulan' 			=> $month,
					'tahun' 			=> $year,
				];

			}

			$insertID = $this->file->insert_entry($data);

	        $inputFileName = './assets/excel/'.$fileInit.'.'.$extension;// path untuk indentifikasi
	         
	        try {
	                $inputFileType = IOFactory::identify($inputFileName);// indentifikasi
	                $objReader = IOFactory::createReader($inputFileType);// reader
	                $objPHPExcel = $objReader->load($inputFileName);
	            } catch(Exception $e) {
	                die('Error loading file "'.pathinfo($inputFileName,PATHINFO_BASENAME).'": '.$e->getMessage());
	            }
	 
	            $sheet = $objPHPExcel->getSheet(0);
	            $highestRow = $sheet->getHighestRow();
	            $highestColumn = $sheet->getHighestColumn();
	            $i = 1; 
	            if($perm != 'admin')
	            {
		            for ($row = $from; $row < $highestRow; $row=16){ // $row = 6 dimulai dari row 6                
		                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
		                                                NULL,
		                                                TRUE,
		                                                FALSE);
		                                                 
		                
			                 $data_aset = array(
				      		'pj_sutr'		=> $rowData[0][15],
				      		'tiang_tr'		=> $rowData[0][16],
				      		'pj_sr'			=> $rowData[0][17],
				      		'km2'			=> $rowData[0][18],
				      		'bulan'			=> $month,
				      		'tahun'			=> $year,
				      		'bln_thn'		=> $month.' '.$year,
				      		'created_at'	=> $date,
				      		'updated_at'		=> $date
			                ); 
		            }
	            }
	            else
	            {
		            for ($row = $from; $row < $highestRow; $row++){ // $row = 6 dimulai dari row 6                
		                $rowData = $sheet->rangeToArray('A' . $row . ':' . $highestColumn . $row,
		                                                NULL,
		                                                TRUE,
		                                                FALSE);
		                                                 
		                //Sesuaikan sama nama kolom tabel di database
		                if($type == 'new') // jika baru
		                {                                
			                 $data_aset[] = array(
				      		'rayon' 		=> $rowData[0][0],
				      		'kode_up'		=> $i++,
				      		'jmh_pylg'		=> $rowData[0][3],
				      		'pj_sutm' 		=> $rowData[0][4],
				      		'tiang_tm' 		=> $rowData[0][5],
				      		'pln_unit'		=> $rowData[0][6],
				      		'pln_buah' 		=> $rowData[0][7],
				      		'pln_jml_kva' 	=> $rowData[0][8],
				      		'pel_unit' 		=> $rowData[0][9],
				      		'pel_buah'		=> $rowData[0][10],
				      		'pel_jml_kva'	=> $rowData[0][11],
				      		'total_unit' 	=> $rowData[0][12],
				      		'total_buah'	=> $rowData[0][13],
				      		'total_jml_kva'	=> $rowData[0][14],
				      		'id_file' 		=> $insertID,
				      		'bulan'			=> $month,
				      		'tahun'			=> $year,
				      		'bln_thn'		=> $month.' '.$year,
				      		'created_at'	=> $date
			                );
			            }
			            if($type == 'update') // jika import
			            {
			            	
			                 $data_aset[] = array(
				      		'rayon' 		=> $rowData[0][0],
				      		'kode_up'		=> $i++,
				      		'jmh_pylg'		=> $rowData[0][3],
				      		'pj_sutm' 		=> $rowData[0][4],
				      		'tiang_tm' 		=> $rowData[0][5],
				      		'pln_unit'		=> $rowData[0][6],
				      		'pln_buah' 		=> $rowData[0][7],
				      		'pln_jml_kva' 	=> $rowData[0][8],
				      		'pel_unit' 		=> $rowData[0][9],
				      		'pel_buah'		=> $rowData[0][10],
				      		'pel_jml_kva'	=> $rowData[0][11],
				      		'total_unit' 	=> $rowData[0][12],
				      		'total_buah'	=> $rowData[0][13],
				      		'total_jml_kva'	=> $rowData[0][14],
				      		'id_file' 		=> $insertID,
				      		'bulan'			=> $month,
				      		'tahun'			=> $year,
				      		'bln_thn'		=> $month.' '.$year,
				      		'created_at'	=> $date,
				      		'updated_at'		=> $date
			                );           	
			            }    
		            }
	            }


	            if($perm == 'admin')
	            {
		            // memasukan data ke database 

		            	$this->db->select('*');
		            	$this->db->from('data');
		            	$this->db->where('rayon', $rowData[0][0]);
		            	$this->db->where('bln_thn', $month.' '.$year);

		            	$query = $this->db->get();
		            	$res   = $query->result();

		            	if(count($res)>0)
		            	{
			            	$this->db->where('bln_thn', $month.' '.$year);
		            		$this->db->update_batch('data', $data_aset, 'rayon');
		            	}
		            	else
		            	{
		            		$this->data->insert_entry($data_aset);
		            	}            	
	            }
	            else
	            {

	            	$this->db->select('*');
	            	$this->db->from('data');
	            	$this->db->where('rayon', $rowData[0][0]);
	            	$this->db->where('bln_thn', $month.' '.$year);

	            	$query = $this->db->get();
	            	$res   = $query->result();

		            if(count($res)>0)// jika import
		            {
		            	$this->db->where('rayon', $rowData[0][0]);
		            	$this->db->where('bln_thn', $month.' '.$year);
		            	$this->db->update('data', $data_aset);
		            }
		            else
		            {
		            	echo "<script>alert('Anda belum bisa mengupload data di bulan ini');</script>";
		            }
	            }


        // akhir kondisi upload
        }
	    // ======= ini adalah proses untuk excel ======================================================================

	}


// akhir model
}