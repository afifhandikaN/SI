<?php
class User_model extends CI_Model {

	// mengambil data user secara desc by id
	public function load_data()
	{
		$this->db->select('*');
		$this->db->from('user');
		$this->db->order_by('id', 'desc');

		$query = $this->db->get();

		return $query->result();
	}

	// ngambil data yg sama
	public function load_data_by_username($key)
	{
		$this->db->select('*');
		$this->db->from('user');
		$this->db->where('username', $key);

		$query = $this->db->get();

		return $query->result();
	}

	// simpan data user
	public function save_data()
	{
		// mengambil inputan
		$type 			= $this->input->post('type');
		$fullname		= $this->input->post('fullname');
		
		$username 		= $this->input->post('username');
		$password 		= $this->input->post('password');
		$perm			= $this->input->post('perm');

		$check_username = $this->load_data_by_username($username);

		// jika tipe tambah user
		if($type == 'addUser')
		{
			if(count($check_username)>0)
			{
				$res = "1";
			}
			else
			{
				$dataUser = array(
						'fullname' 	=> $fullname,
						'username' 	=> $username,
						'password' 	=> md5($password),
						'perm'		=> $perm
					);

				$this->db->insert('user', $dataUser);

				$res = "0";
			}
		}
		else // jika tipe edit use
		{

			$username_last	= $this->input->post('username_last');
			$id_user 		= $this->input->post('id_user');
			// kondisi perm
			$perm_last 		= $this->input->post('perm_last');

			if($perm == NULL)
			{
				$perm = $perm_last;
			}
			else
			{
				$perm = $perm;
			}

			if(isset($password))
			{
				$password = $password;
			}
			else
			{
				$password = NULL;
			}

			if($username_last == $username)
			{
				if($password != NULL)
				{
					$dataUser = array(
						'fullname' 	=> $fullname,
						'password' 	=> md5($password),
						'perm' 		=> $perm
					);

					$this->db->where('id', $id_user);
					$this->db->update('user', $dataUser);
				}
				else
				{
					$dataUser = array(
						'fullname' 	=> $fullname,
						'perm' 		=> $perm
					);

					$this->db->where('id', $id_user);
					$this->db->update('user', $dataUser);
				}

				$res = '0';
			}
			else
			{
				if(count($check_username)>0)
				{
					$res = '1';
				}
				else
				{
					if($password != NULL)
					{
						$dataUser = array(
							'fullname' 	=> $fullname,
							'username'  => $username,
							'password' 	=> md5($password),
							'perm' 		=> $perm
						);

						$this->db->where('id', $id_user);
						$this->db->update('user', $dataUser);
					}
					else
					{
						$dataUser = array(
							'fullname' 	=> $fullname,
							'username'  => $username,
							'perm' 		=> $perm
						);

						$this->db->where('id', $id_user);
						$this->db->update('user', $dataUser);
					}

					$res = '0';
				}
			}
		}

		return $res;
	}

	// fungsi menghapus data user
	public function delete_data($key)
	{
		$this->db->where('username', $key);
		$this->db->delete('user');

		$res = 'User sudah dihapus';

		return $res;
	}

// end model
}