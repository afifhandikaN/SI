
<style type="text/css">
	
.astaff-wrapper
{
    width: 33%;
    margin: auto;
}

</style>

<button style="margin-left: 10px;margin-top: 10px;" id="close" class="btn btn-danger">X</button>

<br>
<br>

<div class="astaff-wrapper">

<h4 style="color: #fff;">Tambah Admin / Staff Baru</h4>
<br>

<form id="inputForm">

<input type="hidden" name="type" value="addUser">

<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-list-alt"></i></span>
    <input id="f" type="text" class="form-control" maxlength="45" name="fullname" placeholder="Nama Lengkap" required="">
  </div>
<br>
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
    <input id="u" type="text" maxlength="45" class="form-control" name="username" placeholder="Username" required="">
</div>
<br>
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
    <input id="p" type="password" class="form-control" name="password" placeholder="Password" required="">
</div>
<br>
<div class="input-group">
    <span class="input-group-addon"><i class="glyphicon glyphicon-random"></i></span>
    <select class="form-control" name="perm" required="">
    	<option value="">-- Pilih Hak Akses --</option>
    	<option value="admin">Admin</option>
    	<option value="mja">MJA</option>
    	<option value="mjk">MJK</option>
    	<option value="jbg">JBG</option>
    	<option value="ngr">NGR</option>
    	<option value="pls">PLS</option>
    	<option value="mjs">MJS</option>
    	<option value="pct">PCT</option>
    	<option value="kts">KTS</option>
    	<option value="wrj">WRJ</option>
    	<option value="ngk">NGK</option>
    </select>
</div>
<br>
<button type="submit" class="btn btn-success">Kirim</button>

</form>

</div>



<script type="text/javascript">
	
// untuk menutup
$('#close').on('click', function(){

	$('#jqContent').slideUp('400');
	$('#jqContent').html('');

});

$(document).on('submit', '#inputForm', function(){


	$.ajax({

		url:base_url+'main_controller/save_admin_staff',
		type:'POST',
		data:new FormData(this),
		contentType:false,
		processData: false,
		success:function(data)
		{
			if(data == '1')
			{
				alert('Username sudah ada silahkan ganti');
			}
			else
			{
				alert('Data sudah disimpan');
				window.location.href = window.location.href;
			}
		}

	});

	return false;

});

</script>