<div class="row">
    <div class="col-lg-12">
        <div class="panel panel-default">
            <div class="panel-heading"><strong>FORM UPLOAD</strong></div>

            <div class="panel-body">
                <div class="row">
                    <form action="<?= base_url() ?>main_controller/upload_process" method="post" enctype="multipart/form-data">
                    <input type="hidden" name="perm" value="<?= $perm ;?>">
                    <div class="col-lg-4">
                        <div class="form-group">
                            <label> Nama File </label><br>
                            <input autofocus class="form-control" type="text" name="nama" size="40" required placeholder="Enter text" />
                            <p class="help-block">Contoh :Data Aset Mei 2017/A_area atau A_Rmja</p>
                        </div>

                        <div class="form-group">
                            <label> Tanggal Upload </label><br>
                            <input class="form-control" value="<?= date("Y-m-d") ?>" readonly type="text" name="tgl" size="40" required/>
                            <p class="help-block">Format : Tahun-Bulan-Tanggal</p>
                        </div>
                        <div class="form-group">
                            <label> Pilih File </label>
                            <input class="form-control" type="file" name="excel" required />
                            <p class="help-block">
                            <a href="<?= base_url() ?>assets/format_excelAdminArea.xlsx">
                                <span class="fa fa-download"></span> Download Format Excel
                            </a>                                
                            </p>
                        </div>
                        <div class="form-group">
                            <button type="submit" class="btn btn-success" name="upload" value="Upload"> Submit <span class="fa fa-check"></span></button>
                            <button type="reset" class="btn btn-warning pull-right" value="Reset"> Reset <span class="fa fa-repeat"></span></button>
                        </div>                                        
                    </div>
                    <div class="col-lg-4">
                    <?php if($perm != 'admin'):?>
                        <input type="hidden" name="tipe" value="update">
                    <?php else:?>
                        <input type="hidden" name="tipe" value="new">
                    <?php endif;?>
                        <div class="form-group">
                            <label>Jenis Upload</label><br>
                            <select class="form-control" name="tipe" required="">
                                <option value="">-- Pilih Jenis Upload --</option>
                                <option value="new">Data Baru</option>
                                <option value="update">Data Perbaikan</option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label> Data Bulan ke </label><br>
                            <?php
                            if (($this->uri->segment(2) >= 1 && $this->uri->segment(2) <= 12)) {
                                $selectName = "";
                                $selected = $this->uri->segment(2);
                                $property = ['class'=>'form-control', 'disabled'=>'disabled'];
                                echo form_hidden('bulan', $selected);
                            }
                            else{
                                $selectName = "bulan";
                                $selected = date("m");
                                $property = ['class'=>'form-control'];
                            }
                            echo form_dropdown($selectName, $bulan, $selected, $property);

                            ?>                            
                            <p class="help-block">Data ini adalah untuk bulan ...</p>
                        </div>
                        <div class="form-group">
                            <label> Data Tahun ke </label><br>
                            <?php
                            echo form_dropdown('tahun', $tahun, date("Y"), ['class'=>'form-control']);
                            ?>                            
                            <p class="help-block">Data ini adalah untuk tahun ...</p>
                        </div>
                    </div>
                    </form>
                    <!-- /.col-lg-4 (nested) -->
                </div>
                <!-- /.row (nested) -->
            </div>
            <!-- /.panel-body -->
        </div>
        <!-- /.panel -->
    </div>
    <!-- /.col-lg-12 -->
</div>