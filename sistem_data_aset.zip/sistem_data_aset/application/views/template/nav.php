<!-- Navigation -->
<nav class="navbar navbar-default navbar-static-top" role="navigation" style="margin-bottom: 0">
    <div class="navbar-header">
        <button type="button" class="navbar-toggle" data-toggle="collapse" data-target=".navbar-collapse">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
        </button>
        <a class="navbar-brand" href="#">PT.PLN (PERSERO) AREA MOJOKERTO</a>
    </div>
    <div class="navbar-default sidebar" role="navigation">
        <div class="sidebar-nav navbar-collapse">
            <ul class="nav" id="side-menu">
                <li class="sidebar-search">
                    <!-- Bukan apa apa -->
                </li>
                
                    <li>
                        <a href="<?= base_url() ?>home"><i class="fa fa-home fa-fw"></i><strong> HOME </strong></a>
                    </li>
                <?php if($perm == 'admin' || $perm == 'guest'):?>
                    <li>
                        <a href="<?= base_url() ?>apj"><i class="fa fa-bar-chart-o fa-fw"></i><strong> DATA APJ </strong></a>
                        <!-- /.nav-second-level -->
                    </li>

                    <li>
                        <a href="<?= base_url() ?>listfile"><i class="fa fa-edit fa-fw"></i><strong> ARSIP DATA </strong></a>
                    </li>
                <?php else:?>
                <?php endif;?>
                 
                <?php if($perm == 'guest'):?>
                <?php else:?>
                <li>
                    <a href="<?= base_url() ?>upload"><i class="fa fa-upload fa-fw"></i><strong> IMPORT / UPLOAD FILE </strong></a>
                </li>
                <?php endif;?>

                <?php if($perm == 'admin'):?>
                    <li>
                        <a href="<?php echo base_url();?>admin_staff"><i class="fa fa-users fa-fw"></i> <STRONG>Data Admin / Staff</STRONG></a>
                    </li>
                <?php else:?>
                <?php endif;?>

                <?php if ($perm != 'guest'):?>
                <li>
                    <a href="<?php echo base_url()?>logout"><i class="fa fa-sign-out fa-fw"></i> <STRONG> LOGOUT </STRONG></a>
                </li>
                <?php else:?>
                <li>
                    <a href="<?php echo base_url()?>login"><i class="fa fa-sign-in fa-fw"></i> <STRONG> LOGIN </STRONG></a>
                </li>
                <?php endif;?>
            </ul>
        </div>
        <!-- /.sidebar-collapse -->
    </div>
    <!-- /.navbar-static-side -->
</nav>