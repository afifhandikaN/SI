<div class="row">
    <div class="col-lg-12">
        <button id="addUser" class="btn btn-success"><i class="fa fa-plus"></i> Tambah Admin / Staff</button>
        <br>
        <Br>
        <div class="panel panel-default">
            <div class="panel-heading"><strong>DATA ADMIN DAN STAFF</strong></div>
            <div class="panel-body">
            	<table class="table table-striped table-bordered table-hover" id="dataTables-file">
                    <thead>
                        <tr align="text-center">
                            <th>No.</th>
                            <th>Nama Lengkap</th>
                            <th>Username</th>
                            <th>Hak Akses</th>
                            <th>Action</th>
                        </tr>
                    </thead>

                    <tbody>
                    <?php
                    $i = 1;
                    foreach ($user_data as $key => $value) { 
                    	?>
                    	<tr>
                    		<td><?= $i ?></td>
                    		<td><?= $value->fullname ?></td>
                    		<td><?= $value->username ?></td>
                    		<td><?= $value->perm ?></td>
                    		<td align="center"><a id="editUser" href="<?= $value->username ?>" class="btn btn-primary"><i class="fa fa-edit"></i></a>&nbsp&nbsp&nbsp
                            <a id="delUser" href="<?= $value->username ?>" class="btn btn-danger"><i class="fa fa-trash"></i></a></td>
                    	</tr>
                    <?php 
                    	$i++;
                    }
                    ?>

                    </tbody>
				</table>
            </div>
        </div>
    </div>
</div>
 <script src="<?= base_url() ?>assets/admin/vendor/jquery/jquery.min.js"></script>
<script type="text/javascript">
    
$('#addUser').on('click', function(){

    $('#jqContent').slideDown('400');
    $('#jqContent').load(base_url+'main_controller/view_add_admin_staff');

});

$(document).on('click', '#editUser', function(){

    var username = $(this).attr('href');

    $('#jqContent').slideDown('400');
    $('#jqContent').load(base_url+'main_controller/view_edit_admin_staff/'+username);

    return false

});

$(document).on('click', '#delUser', function(){

    var username = $(this).attr('href');
    var c        = confirm('Anda yakin ingin menghapus user ini ?');


    if(c == true)
    {
        $.get(base_url+'main_controller/delete_admin_staff/'+username, function(data)
        {
            alert(data);
            window.location.href = window.location.href;
        });
    }

    return false;

});

</script>