<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');
 
/*
 * This helper for convert normal number to RP
 *
 *
 */

if ( ! function_exists('month'))
{
	function month($var = '')
	{
		$date = array("Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember");
		return strtoupper($date[$var - 1]);
	}
}