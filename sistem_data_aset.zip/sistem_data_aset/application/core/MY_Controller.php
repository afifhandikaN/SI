<?php

/**
 * @author      autrhor
 * @package     Codeigniter
*/

//--------------------------------------------------------------------------------------

/**
 *
 * Class ini untuk cek login user, dan juga templating
*/

class MY_controller extends CI_Controller // class My_controller
{
    public function __construct()
    {
        parent::__construct();
    }

    /**
     *
     * Fungsi is_logged_in
     *
     * Fungsi ini untuk cek session jika sudah login atau belum
     *
    */ 
    public function is_logged_in()
    {
        $user =	$this->session->userdata('logged_in');
        return isset($user);
    }
    // akhir is_logged_in

    /**
     *
     * Fungsi logged_data
     *
     * Ini untuk mengambil data sessi user
     * Cara pemanggilan nya di controller yang terextend MY_Controller
     * Cara memanggil nya dengan $this->logged_data('kata kunci')
     *
     * Daftar dan guna data kunci
     *
     *  - id            = untuk memanggil id user
     *  - fullname      = untuk mengambil data fullname
     *  - username      = untuk mengambil data username
     *  - perm          = untuk mengambil data perm, perm digunakan untuk hak akses user
     *
    */
    public function logged_data($key)
    {
        $session_data = $this->session->userdata('logged_in');

        if($key == "id")
        {
            return $session_data['id'];
        }
        elseif($key == "fullname")
        {
            return $session_data['fullname'];
        }
        elseif($key == "username")
        {
            return $session_data['username'];
        }
        elseif($key == "perm")
        {
            return $session_data['perm'];
        }

    }
    // fungsi logged_data berakhir

    public function template($data)
    {
        $this->load->view('template/template', $data);
    }
    /* TEMPLATE PUBLIC
    public function public_template($var)
    {
        $this->load->view('public/template/head', $var);
        $this->load->view('public/template/menu_head', $var);
        $this->load->view('public/template/content', $var);
    }
    */



// akhir dari controller
}

